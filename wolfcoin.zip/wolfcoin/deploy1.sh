#!/bin/bash

# Exit on error
set -e

echo "Starting WolfCoin prerequisites installation..."

# Update system
echo "Updating system packages..."
sudo apt-get update && sudo apt-get upgrade -y

# Install essential packages
echo "Installing essential packages..."
sudo apt-get install -y \
    curl \
    wget \
    git \
    build-essential \
    software-properties-common \
    gnupg \
    lsb-release \
    ca-certificates

# Install Python 3.11
echo "Installing Python 3.11..."
sudo add-apt-repository ppa:deadsnakes/ppa -y
sudo apt-get update
sudo apt-get install -y python3.11 python3.11-venv python3.11-dev

# Install Node.js and npm
echo "Installing Node.js and npm..."
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo npm install -g npm@latest

# Install and configure PostgreSQL
echo "Installing PostgreSQL..."
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/postgresql/sources.list.d/pgdg.list'
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
sudo apt-get update
sudo apt-get install -y postgresql postgresql-contrib

# Install Nginx
echo "Installing Nginx..."
sudo apt-get install -y nginx

# Install monitoring tools
echo "Installing monitoring tools..."
sudo apt-get install -y \
    prometheus \
    prometheus-node-exporter \
    grafana

# Install security tools
echo "Installing security tools..."
sudo apt-get install -y \
    fail2ban \
    ufw \
    unattended-upgrades \
    apt-listchanges

# Install PM2 globally
echo "Installing PM2..."
sudo npm install -g pm2

# Create required directories
echo "Creating required directories..."
sudo mkdir -p /var/www/wolfcoin
sudo mkdir -p /var/log/wolfcoin
sudo mkdir -p /backup/wolfcoin

# Set permissions
sudo chown -R www-data:www-data /var/www/wolfcoin
sudo chown -R www-data:www-data /var/log/wolfcoin
sudo chown -R www-data:www-data /backup/wolfcoin

# Configure unattended-upgrades
echo "Configuring unattended-upgrades..."
sudo dpkg-reconfigure -plow unattended-upgrades

# Configure automatic updates
cat > /etc/apt/apt.conf.d/20auto-upgrades <<EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "7";
EOF

# Basic UFW setup
echo "Configuring basic firewall rules..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https

# Create system user for the application
echo "Creating system user..."
sudo useradd -r -s /bin/false wolfcoin || true

# Verify installations
echo "Verifying installations..."
python3.11 --version
node --version
npm --version
postgres --version
nginx -v
pm2 --version

echo "Prerequisites installation completed!"
echo "Next steps:"
echo "1. Run deploy.sh to configure and start the application"
echo "2. Configure SSL certificates"
echo "3. Set up domain DNS"
echo "4. Configure PostgreSQL password and users"

# Create status file
echo "$(date)" > /var/www/wolfcoin/prerequisites-installed.txt