-- AlterTable
ALTER TABLE "boosts" ADD COLUMN     "name" VARCHAR(255);
