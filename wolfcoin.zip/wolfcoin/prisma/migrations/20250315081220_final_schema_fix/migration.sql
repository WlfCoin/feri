/*
  Warnings:

  - You are about to drop the column `user_id` on the `boosts` table. All the data in the column will be lost.
  - You are about to alter the column `multiplier` on the `boosts` table. The data in that column could be lost. The data in that column will be cast from `Decimal(65,30)` to `Decimal(10,2)`.
  - You are about to drop the `transactions` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "boosts" DROP CONSTRAINT "boosts_user_id_fkey";

-- DropForeignKey
ALTER TABLE "mining_sessions" DROP CONSTRAINT "mining_sessions_user_id_fkey";

-- DropForeignKey
ALTER TABLE "transactions" DROP CONSTRAINT "transactions_user_id_fkey";

-- DropForeignKey
ALTER TABLE "users" DROP CONSTRAINT "users_referred_by_fkey";

-- AlterTable
ALTER TABLE "boosts" DROP COLUMN "user_id",
ALTER COLUMN "multiplier" SET DATA TYPE DECIMAL(10,2);

-- AlterTable
ALTER TABLE "userBooster" ALTER COLUMN "purchaseDate" SET DEFAULT CURRENT_TIMESTAMP;

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "address" VARCHAR(255);

-- DropTable
DROP TABLE "transactions";

-- AddForeignKey
ALTER TABLE "mining_sessions" ADD CONSTRAINT "mining_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_referred_by_fkey" FOREIGN KEY ("referred_by") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
