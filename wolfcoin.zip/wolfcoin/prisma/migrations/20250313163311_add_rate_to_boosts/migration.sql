/*
  Warnings:

  - Added the required column `rate` to the `boosts` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "boosts" ADD COLUMN     "rate" DECIMAL NOT NULL;
