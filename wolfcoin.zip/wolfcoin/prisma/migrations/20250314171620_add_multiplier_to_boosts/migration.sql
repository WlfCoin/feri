/*
  Warnings:

  - Added the required column `end_time` to the `boosts` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "boosts" ADD COLUMN     "end_time" TIMESTAMP(6) NOT NULL,
ADD COLUMN     "multiplier" DECIMAL(65,30) NOT NULL DEFAULT 1.0,
ADD COLUMN     "start_time" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "status" VARCHAR(50) NOT NULL DEFAULT 'active';
