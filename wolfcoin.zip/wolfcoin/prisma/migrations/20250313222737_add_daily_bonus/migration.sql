-- CreateTable
CREATE TABLE "dailyBonus" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "claimed" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "dailyBonus_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "dailyBonus" ADD CONSTRAINT "dailyBonus_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
