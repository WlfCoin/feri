/*
  Warnings:

  - You are about to alter the column `rate` on the `boosts` table. The data in that column could be lost. The data in that column will be cast from `Decimal` to `Integer`.

*/
-- AlterTable
ALTER TABLE "boosts" ALTER COLUMN "name" SET DATA TYPE TEXT,
ALTER COLUMN "cost" DROP NOT NULL,
ALTER COLUMN "rate" DROP NOT NULL,
ALTER COLUMN "rate" SET DATA TYPE INTEGER,
ALTER COLUMN "requiredBoosterId" SET DATA TYPE TEXT;

-- CreateTable
CREATE TABLE "userBooster" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "boosterId" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "startTime" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "endTime" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "userBooster_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "userBooster" ADD CONSTRAINT "userBooster_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "userBooster" ADD CONSTRAINT "userBooster_boosterId_fkey" FOREIGN KEY ("boosterId") REFERENCES "boosts"("id") ON DELETE CASCADE ON UPDATE CASCADE;
