-- AlterTable
ALTER TABLE "boosts" ADD COLUMN     "requiredBoosterId" VARCHAR(255);
