from typing import Dict, Any
from dataclasses import dataclass
from datetime import datetime

@dataclass
class UserState:
    state: str
    data: Dict[str, Any]
    timestamp: datetime

class StateManager:
    def __init__(self):
        self._states: Dict[int, UserState] = {}
    
    def set_state(self, user_id: int, state: str, data: Dict[str, Any] = None) -> None:
        self._states[user_id] = UserState(
            state=state,
            data=data or {},
            timestamp=datetime.now()
        )
    
    def get_state(self, user_id: int) -> UserState:
        return self._states.get(user_id)
    
    def clear_state(self, user_id: int) -> None:
        if user_id in self._states:
            del self._states[user_id]
    
    def update_state_data(self, user_id: int, data: Dict[str, Any]) -> None:
        if user_id in self._states:
            current_state = self._states[user_id]
            current_state.data.update(data)
            current_state.timestamp = datetime.now()
    
    def get_state_data(self, user_id: int, key: str) -> Any:
        state = self.get_state(user_id)
        return state.data.get(key) if state else None
