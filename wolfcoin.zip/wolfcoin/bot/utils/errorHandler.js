const handleError = async (error, ctx) => {
    console.error('Bot error:', {
        error: error.message,
        stack: error.stack,
        update: ctx.update,
        user: ctx.from
    });

    try {
        // Send user-friendly error message
        const message = getUserFriendlyError(error);
        await ctx.reply(message, { parse_mode: 'HTML' });
    } catch (replyError) {
        console.error('Error sending error message:', replyError);
    }
};

const getUserFriendlyError = (error) => {
    // Map common errors to user-friendly messages
    const errorMap = {
        'ETELEGRAM': '❌ Telegram API error. Please try again later.',
        'Error: 400: Bad Request': '❌ Invalid request. Please try again.',
        'Error: 403: Forbidden': '❌ Bot does not have required permissions.',
        'Error: 429: Too Many Requests': '⚠️ Too many requests. Please wait a moment.',
        'MongoError': '❌ Database error. Please try again later.',
        'ValidationError': '❌ Invalid data provided.',
        'TokenExpiredError': '🔑 Your session has expired. Please /start again.',
        'JsonWebTokenError': '🔑 Authentication error. Please /start again.'
    };

    // Check if error message matches any known errors
    for (const [errorType, message] of Object.entries(errorMap)) {
        if (error.message.includes(errorType)) {
            return message;
        }
    }

    // Default error message
    return '❌ An error occurred. Please try again or contact support.';
};

module.exports = { handleError };
