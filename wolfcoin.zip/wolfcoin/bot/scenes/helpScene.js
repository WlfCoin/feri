const { Scenes } = require('telegraf');
const { getHelpKeyboard } = require('../utils/keyboard');

const helpScene = new Scenes.BaseScene('help');

helpScene.enter(async (ctx) => {
    try {
        await showMainHelp(ctx);
    } catch (error) {
        console.error('Help scene error:', error);
        await ctx.reply(
            '❌ An error occurred. Please try again or contact support.'
        );
    }
});

const showMainHelp = async (ctx) => {
    const message = 
        '❓ Help Center\n\n' +
        'Welcome to WolfCoin Mining Bot Help Center!\n\n' +
        'Choose a topic below to learn more:';

    await ctx.reply(message, {
        parse_mode: 'HTML',
        reply_markup: getHelpKeyboard()
    });
};

helpScene.action('help_play', async (ctx) => {
    const message = 
        '🎮 How to Play\n\n' +
        '1. Start Mining:\n' +
        '   - Use /mine or click ⛏️ Mine\n' +
        '   - Click "Start Mining" to begin\n' +
        '   - Let the bot mine for you\n' +
        '   - Click "Claim Points" to collect\n\n' +
        '2. Complete Tasks:\n' +
        '   - Use /tasks or click 🎯 Tasks\n' +
        '   - Follow social media\n' +
        '   - Join channels/groups\n' +
        '   - Verify completion\n\n' +
        '3. Claim Bonuses:\n' +
        '   - Use /bonus or click 🎁 Bonus\n' +
        '   - Claim daily bonus\n' +
        '   - Maintain streak for multiplier\n\n' +
        '4. Buy Boosts:\n' +
        '   - Use /boost or click 🚀 Boost\n' +
        '   - Increase mining rate\n' +
        '   - Extend offline mining time\n\n' +
        '5. Check Profile:\n' +
        '   - Use /profile or click 👤 Profile\n' +
        '   - View statistics\n' +
        '   - Share referral link';

    await ctx.editMessageText(message, {
        parse_mode: 'HTML',
        reply_markup: getHelpKeyboard()
    });
});

helpScene.action('help_points', async (ctx) => {
    const message = 
        '💎 About Points\n\n' +
        '1. Earning Points:\n' +
        '   - Mining: 0.5-5 points/hour\n' +
        '   - Tasks: 5-50 points each\n' +
        '   - Daily Bonus: 10+ points\n' +
        '   - Referrals: 2 points each\n\n' +
        '2. Point Multipliers:\n' +
        '   - Mining Boosts: Up to 5x\n' +
        '   - Streak Bonus: Up to 5x\n' +
        '   - Special Events: Varies\n\n' +
        '3. Using Points:\n' +
        '   - Buy boosts\n' +
        '   - Exchange for TON\n' +
        '   - Special promotions\n\n' +
        '4. Point Limits:\n' +
        '   - No maximum limit\n' +
        '   - Points never expire\n' +
        '   - Non-transferable';

    await ctx.editMessageText(message, {
        parse_mode: 'HTML',
        reply_markup: getHelpKeyboard()
    });
});

helpScene.action('help_mining', async (ctx) => {
    const message = 
        '🔄 About Mining\n\n' +
        '1. Mining Process:\n' +
        '   - Automatic mining\n' +
        '   - Runs in background\n' +
        '   - Regular updates\n' +
        '   - Claim anytime\n\n' +
        '2. Mining Rate:\n' +
        '   - Base: 0.5 points/hour\n' +
        '   - Boosts: Up to 5x\n' +
        '   - Offline mining\n' +
        '   - Auto-accumulation\n\n' +
        '3. Offline Mining:\n' +
        '   - Default: 4 hours\n' +
        '   - Extendable with boosts\n' +
        '   - Maximum: 24 hours\n' +
        '   - Auto-claims at limit\n\n' +
        '4. Mining Tips:\n' +
        '   - Use boosts strategically\n' +
        '   - Claim regularly\n' +
        '   - Stack multipliers\n' +
        '   - Monitor rates';

    await ctx.editMessageText(message, {
        parse_mode: 'HTML',
        reply_markup: getHelpKeyboard()
    });
});

helpScene.action('help_support', async (ctx) => {
    const message = 
        '📞 Support\n\n' +
        '1. Common Issues:\n' +
        '   - Mining not starting\n' +
        '   - Points not claiming\n' +
        '   - Task verification failed\n' +
        '   - Payment issues\n\n' +
        '2. Quick Fixes:\n' +
        '   - Restart bot (/start)\n' +
        '   - Check internet connection\n' +
        '   - Verify task requirements\n' +
        '   - Wait for confirmations\n\n' +
        '3. Contact Support:\n' +
        '   - Support channel: @WolfCoinSupport\n' +
        '   - Email: support@wolfcoin.com\n' +
        '   - Response time: 24-48 hours\n\n' +
        '4. Report Issues:\n' +
        '   - Be specific\n' +
        '   - Include screenshots\n' +
        '   - Provide user ID\n' +
        '   - List steps to reproduce';

    await ctx.editMessageText(message, {
        parse_mode: 'HTML',
        reply_markup: getHelpKeyboard()
    });
});

module.exports = { helpScene };
