const fetch = require('node-fetch');

const REQUIRED_CHANNELS = [
    '@WolfcoinOfficial',
    '@WolfcoinCommunity'
];

const checkMembership = async (ctx) => {
    try {
        const telegramId = ctx.from.id;
        
        for (const channel of REQUIRED_CHANNELS) {
            const res = await fetch(`https://api.telegram.org/bot${process.env.BOT_TOKEN}/getChatMember?chat_id=${channel}&user_id=${telegramId}`);
            const data = await res.json();

            if (!data.ok || (data.result.status !== 'member' && data.result.status !== 'administrator' && data.result.status !== 'creator')) {
                return false;
            }
        }
        return true;
    } catch (error) {
        console.error('Error checking Telegram membership:', error);
        return false;
    }
};

const startScene = async (ctx) => {
    try {
        const isMember = await checkMembership(ctx);
        
        if (!isMember) {
            return ctx.reply('?? You must join our official channels to access the mini-app.\nJoin and try again:', {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Join Channel 1', url: 'https://t.me/WolfcoinOfficial' }],
                        [{ text: 'Join Channel 2', url: 'https://t.me/WolfcoinCommunity' }]
                    ]
                }
            });
        }

        const userId = ctx.from.id;
        const miniAppLink = `https://t.me/WolfCoinMiniApp?start=${userId}`;
        return ctx.reply(`? Welcome to Wolfcoin!\nClick the link below to access the mini-app:`, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: 'Open Mini-App', url: miniAppLink }]
                ]
            }
        });
    } catch (error) {
        console.error('Error in start scene:', error);
        return ctx.reply('? An error occurred. Please try again later.');
    }
};

module.exports = startScene;
