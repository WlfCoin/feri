let miningInterval = null;
let startTime = 0;
let userId = 0;
let miningRate = 0;
let duration = 0;

self.addEventListener('message', async (e) => {
  const { type, data } = e.data;

  switch (type) {
    case 'START_MINING':
      const { id, rate, baseDuration } = data;
      userId = id;
      miningRate = rate;
      duration = baseDuration * 3600000; // تبدیل ساعت به میلی‌ثانیه
      startTime = Date.now();
      
      if (!miningInterval) {
        miningInterval = setInterval(async () => {
          try {
            // اگر زمان ماینینگ تمام شده
            if (Date.now() - startTime >= duration) {
              clearInterval(miningInterval);
              miningInterval = null;
              self.postMessage({ type: 'MINING_COMPLETE' });
              return;
            }

            // ارسال درخواست به سرور برای به‌روزرسانی امتیاز
            const response = await fetch('/api/mining/update', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                userId,
                amount: miningRate,
              }),
            });

            if (!response.ok) throw new Error('Mining update failed');

            const result = await response.json();
            self.postMessage({ 
              type: 'MINING_UPDATE',
              data: { 
                balance: result.balance,
                timeLeft: duration - (Date.now() - startTime)
              }
            });
          } catch (error) {
            console.error('Mining error:', error);
          }
        }, 3600000); // هر ساعت
      }
      break;

    case 'STOP_MINING':
      if (miningInterval) {
        clearInterval(miningInterval);
        miningInterval = null;
      }
      break;

    case 'GET_STATUS':
      if (miningInterval) {
        self.postMessage({ 
          type: 'MINING_STATUS',
          data: {
            isActive: true,
            timeLeft: duration - (Date.now() - startTime)
          }
        });
      } else {
        self.postMessage({ 
          type: 'MINING_STATUS',
          data: { isActive: false }
        });
      }
      break;
  }
});
