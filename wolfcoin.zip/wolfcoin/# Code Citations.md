# Code Citations

## License: Apache-2.0
https://github.com/TracecatHQ/tracecat/blob/f5654f55c835af3ffef8e06b83c9a050d64ce5cf/scripts/auto-update.sh

```
automatic updates
cat > /etc/
```


## License: Apache-2.0
https://github.com/TracecatHQ/tracecat/blob/f5654f55c835af3ffef8e06b83c9a050d64ce5cf/scripts/auto-update.sh

```
automatic updates
cat > /etc/apt/apt.conf.d/
```


## License: Apache-2.0
https://github.com/TracecatHQ/tracecat/blob/f5654f55c835af3ffef8e06b83c9a050d64ce5cf/scripts/auto-update.sh

```
automatic updates
cat > /etc/apt/apt.conf.d/20auto-upgrades <<EOF
```


## License: Apache-2.0
https://github.com/TracecatHQ/tracecat/blob/f5654f55c835af3ffef8e06b83c9a050d64ce5cf/scripts/auto-update.sh

```
automatic updates
cat > /etc/apt/apt.conf.d/20auto-upgrades <<EOF
APT::Periodic::Update-
```


## License: Apache-2.0
https://github.com/TracecatHQ/tracecat/blob/f5654f55c835af3ffef8e06b83c9a050d64ce5cf/scripts/auto-update.sh

```
automatic updates
cat > /etc/apt/apt.conf.d/20auto-upgrades <<EOF
APT::Periodic::Update-Package-Lists "1";
AP
```


## License: Apache-2.0
https://github.com/TracecatHQ/tracecat/blob/f5654f55c835af3ffef8e06b83c9a050d64ce5cf/scripts/auto-update.sh

```
automatic updates
cat > /etc/apt/apt.conf.d/20auto-upgrades <<EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unatt
```


## License: Apache-2.0
https://github.com/TracecatHQ/tracecat/blob/f5654f55c835af3ffef8e06b83c9a050d64ce5cf/scripts/auto-update.sh

```
automatic updates
cat > /etc/apt/apt.conf.d/20auto-upgrades <<EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
```


## License: Apache-2.0
https://github.com/TracecatHQ/tracecat/blob/f5654f55c835af3ffef8e06b83c9a050d64ce5cf/scripts/auto-update.sh

```
automatic updates
cat > /etc/apt/apt.conf.d/20auto-upgrades <<EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::
```

