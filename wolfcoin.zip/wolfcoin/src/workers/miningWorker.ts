let miningActive = false;
let startTime = 0;
let duration = 0;
let userId = 0;
let miningRate = 0;

self.addEventListener('message', async (e: MessageEvent) => {
  const { type, data } = e.data;

  switch (type) {
    case 'START_MINING':
      ({ id: userId, rate: miningRate, baseDuration: duration } = data);
      startTime = Date.now();
      duration = duration * 3600000; 
      miningActive = true;
      self.postMessage({ type: 'MINING_STARTED', data: { timeLeft: duration } });
      break;

    case 'STOP_MINING':
      miningActive = false;
      await finalizeMining();
      break;

    case 'GET_STATUS':
      const timeElapsed = Date.now() - startTime;
      const timeLeft = duration - timeElapsed;
      self.postMessage({
        type: 'MINING_STATUS',
        data: {
          isActive: miningActive && timeLeft > 0,
          timeLeft: timeLeft > 0 ? timeLeft : 0
        },
      });
      break;
  }
});

async function finalizeMining() {
  try {
    const response = await fetch('/api/mining/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId,
        startTime,
        endTime: Date.now(),
        miningRate,
      }),
    });

    if (!response.ok) throw new Error('Failed to finalize mining');

    const result = await response.json();
    self.postMessage({
      type: 'MINING_COMPLETE',
      data: {
        balance: result.balance,
      },
    });
  } catch (error) {
    self.postMessage({
      type: 'MINING_ERROR',
      data: { message: error.message },
    });
    console.error('Mining finalization error:', error);
  }
}
