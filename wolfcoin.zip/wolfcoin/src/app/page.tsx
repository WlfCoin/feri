'use client';

import React from 'react';
import Miner from "@/components/Miner";

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <Miner />
    </div>
  );
}
