import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

const TASK_POINTS = {
  telegram_news: 5,
  telegram_activity: 5
};

export async function POST(req: NextRequest) {
  try {
    const { userId, taskId } = await req.json();

    if (!userId || !taskId) {
      return NextResponse.json(
        { message: 'Missing required parameters' },
        { status: 400 }
      );
    }

    const existingVerification = await prisma.taskVerification.findFirst({
      where: {
        userId: userId,
        taskId: taskId,
        verified: true
      }
    });

    if (existingVerification) {
      return NextResponse.json(
        { message: 'Task already verified' },
        { status: 400 }
      );
    }

    const verification = await prisma.taskVerification.create({
      data: {
        userId: userId,
        taskId: taskId,
        verified: true,
        verifiedAt: new Date()
      }
    });

    await prisma.users.update({
      where: { id: parseInt(userId) },
      data: {
        balance: { increment: TASK_POINTS[taskId] || 0 },
        updated_at: new Date()
      }
    });

    return NextResponse.json({ verified: true });
  } catch (error) {
    console.error('Error verifying task:', error);
    return NextResponse.json(
      { message: 'Error verifying task' },
      { status: 500 }
    );
  }
}
