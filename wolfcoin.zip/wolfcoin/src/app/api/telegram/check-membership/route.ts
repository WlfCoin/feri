import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { userId, channelId } = await req.json();

    if (!userId || !channelId) {
      return NextResponse.json(
        { message: 'Missing required parameters' },
        { status: 400 }
      );
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      throw new Error('TELEGRAM_BOT_TOKEN is not configured');
    }

    const response = await fetch(
      `https://api.telegram.org/bot${botToken}/getChatMember?chat_id=${channelId}&user_id=${userId}`
    );

    const data = await response.json();
    const isMember = data.ok && ['member', 'administrator', 'creator'].includes(data.result.status);

    return NextResponse.json({ isMember });
  } catch (error) {
    console.error('Error checking membership:', error);
    return NextResponse.json(
      { message: 'Error checking membership' },
      { status: 500 }
    );
  }
}
