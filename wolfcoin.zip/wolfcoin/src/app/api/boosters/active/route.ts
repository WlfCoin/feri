// active/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    const activeBoosters = await prisma.userBooster.findMany({
      where: {
        userId: parseInt(userId),
        isActive: true,
        OR: [
          { expiryDate: null },
          { expiryDate: { gt: new Date() } }
        ]
      },
      include: {
        booster: {
          select: {
            id: true,
            name: true,
            rate: true,
            type: true,
            requiredBoosterId: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      activeBoosters: activeBoosters.map((ub) => ({
        id: ub.booster.id,
        name: ub.booster.name,
        rate: ub.booster.rate,
        type: ub.booster.type,
        requiredBoosterId: ub.booster.requiredBoosterId,
        purchaseDate: ub.purchaseDate,
        expiryDate: ub.expiryDate,
        isActive: ub.isActive
      })),
    });

  } catch (error) {
    console.error('Error fetching active boosters:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch active boosters',
      },
      { status: 500 }
    );
  }
}
