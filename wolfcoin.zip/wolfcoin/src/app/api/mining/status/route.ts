import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const miningSession = await prisma.mining_sessions.findFirst({
      where: { user_id: parseInt(userId), status: 'active' }
    });

    return NextResponse.json({
      success: true,
      data: miningSession
    });
  } catch (error) {
    console.error('Error fetching mining status:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
