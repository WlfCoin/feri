// status/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const completedTasks = await prisma.completedTasks.findMany({
      where: { userId: parseInt(userId) },
      select: {
        taskId: true,
        completedAt: true
      }
    });

    return NextResponse.json({
      success: true,
      tasks: completedTasks.map((task) => ({
        taskId: task.taskId,
        completed: true,
        timestamp: task.completedAt
      }))
    });
  } catch (error) {
    console.error('Error fetching task status:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
