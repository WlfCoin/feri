// claim/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

const POINTS_BY_DAY = [5, 6, 7, 8, 9, 10, 11];

export async function POST(request: Request) {
  try {
    const { userId } = await request.json();

    const now = new Date();

    const existingBonus = await prisma.dailyBonus.findFirst({
      where: {
        userId,
        createdAt: {
          gte: new Date(now.setHours(0, 0, 0, 0)),
          lt: new Date(now.setHours(23, 59, 59, 999))
        }
      }
    });

    if (existingBonus) {
      return NextResponse.json(
        { error: 'Daily bonus already claimed today' },
        { status: 400 }
      );
    }

    const amount = POINTS_BY_DAY[0];

    await prisma.dailyBonus.create({
      data: {
        userId,
        bonus: amount,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    });

    const user = await prisma.users.update({
      where: { id: userId },
      data: {
        balance: { increment: amount },
        updated_at: new Date()
      }
    });

    await prisma.transactions.create({
      data: {
        user_id: userId,
        amount,
        type: 'BONUS',
        status: 'completed',
        created_at: new Date()
      }
    });

    return NextResponse.json({
      success: true,
      amount,
      balance: user.balance
    });
  } catch (error) {
    console.error('Daily bonus claim error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
