// twitter/connect/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ success: false, error: 'User ID is required' }, { status: 400 });
    }

    const authUrl = `${process.env.TWITTER_AUTH_URL}?client_id=${process.env.TWITTER_CLIENT_ID}&redirect_uri=${process.env.TWITTER_REDIRECT_URI}&state=${userId}`;

    await prisma.users.update({
      where: { id: parseInt(userId) },
      data: { last_active: new Date() }
    });

    return NextResponse.json({ success: true, data: { auth_url: authUrl } });
  } catch (error) {
    console.error('Error connecting to Twitter:', error);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}
