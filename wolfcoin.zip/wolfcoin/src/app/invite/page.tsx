'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import styles from '@/styles/Invite.module.css';

interface Referral {
  username: string;
  joinedAt: string;
}

export default function InvitePage() {
  const { user } = useAuth();
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [copied, setCopied] = useState(false);

  const userId = user?.id || '';
  const inviteLink = userId ? `https://t.me/WolfCoinrobot?start=${userId}` : '';

  useEffect(() => {
    if (!userId) return;

    const fetchReferrals = async () => {
      try {
        const response = await fetch(`/api/referrals?userId=${userId}`);
        const data = await response.json();
        if (data.success) {
          setReferrals(data.referrals);
        }
      } catch (error) {
        console.error('Error fetching referrals:', error);
      }
    };

    fetchReferrals();
  }, [userId]);

  const handleCopy = async () => {
    if (!inviteLink) return;

    try {
      await navigator.clipboard.writeText(inviteLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  if (!userId) {
    return (
      <div className={styles.container}>
        <h1 className={styles.title}>Please login to view your invite link.</h1>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Invite wolves to your pack</h1>

      <div className={styles.inviteLinkBox} onClick={handleCopy}>
        <span className={styles.linkText}>{inviteLink}</span>
        <span className={styles.copyIndicator}>
          {copied ? 'Copied!' : 'Click to copy'}
        </span>
      </div>

      <div className={styles.referralsList}>
        <h2>Your Pack Members</h2>
        {referrals.length > 0 ? (
          <ul>
            {referrals.map((referral, index) => (
              <li key={index} className={styles.referralItem}>
                <span className={styles.username}>{referral.username}</span>
                <span className={styles.joinDate}>
                  {new Date(referral.joinedAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className={styles.noReferrals}>No wolves in your pack yet</p>
        )}
      </div>
    </div>
  );
}
