'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import styles from './Admin.module.css';

interface User {
  id: number;
  address: string;
  balance: number;
  miningRate: number;
}

interface Booster {
  id: string;
  name: string;
  cost: number;
  rate: number;
  type: 'HUNTING_RATE' | 'OFFLINE_HUNT';
  requiredBoosterId?: string;
}

export default function AdminPanel() {
  const router = useRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [boosters, setBoosters] = useState<Booster[]>([]);
  const [activeTab, setActiveTab] = useState('users');
  const [isAuthorized, setIsAuthorized] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      const adminIds = process.env.NEXT_PUBLIC_ADMIN_IDS?.split(',') || [];
      const tg = window.Telegram?.WebApp;
      const currentUserId = tg?.initDataUnsafe?.user?.id?.toString();

      if (currentUserId && adminIds.includes(currentUserId)) {
        setIsAuthorized(true);
        fetchData();
      } else {
        router.push('/');
      }
    };
    checkAuth();
  }, []);

  const fetchData = async () => {
    try {
      const [usersRes, boostersRes] = await Promise.all([
        fetch('/api/admin/users'),
        fetch('/api/admin/boosters')
      ]);

      const usersData = await usersRes.json();
      const boostersData = await boostersRes.json();

      setUsers(usersData.users || []);
      setBoosters(boostersData.boosters || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const updateUserBalance = async (userId: number, newBalance: number) => {
    try {
      await fetch('/api/admin/users/balance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, balance: newBalance })
      });
      fetchData();
    } catch (error) {
      console.error('Error updating user balance:', error);
    }
  };

  return (
    <div className={styles.adminPanel}>
      {isAuthorized && (
        <div>
          <div className={styles.tabs}>
            <button onClick={() => setActiveTab('users')} className={activeTab === 'users' ? styles.activeTab : ''}>
              Users
            </button>
            <button onClick={() => setActiveTab('boosters')} className={activeTab === 'boosters' ? styles.activeTab : ''}>
              Boosters
            </button>
          </div>

          {activeTab === 'users' && (
            <div className={styles.usersSection}>
              {users.map((user) => (
                <div key={user.id} className={styles.userCard}>
                  <div>Address: {user.address}</div>
                  <div>Balance: {user.balance}</div>
                  <input
                    type="number"
                    defaultValue={user.balance}
                    onBlur={(e) => updateUserBalance(user.id, parseFloat(e.target.value))}
                    className={styles.input}
                  />
                </div>
              ))}
            </div>
          )}

          {activeTab === 'boosters' && (
            <div className={styles.boostersSection}>
              {boosters.map((booster) => (
                <div key={booster.id} className={styles.boosterCard}>
                  <div>Name: {booster.name}</div>
                  <div>Cost: {booster.cost} TON</div>
                  <div>Rate: {booster.rate}x</div>
                  <div>Type: {booster.type}</div>
                  {booster.requiredBoosterId && (
                    <div>Required Booster: {booster.requiredBoosterId}</div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
