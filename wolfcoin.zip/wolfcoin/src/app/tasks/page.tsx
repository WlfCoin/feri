'use client';

import React from 'react';
import Tasks from '@/components/Tasks';
import { useAuth } from '@/contexts/AuthContext';
import styles from '@/styles/Tasks.module.css';

export default function TasksPage() {
  const { user } = useAuth();
  const userId = user?.id || 0;

  const updateBalance = async (amount: number) => {
    try {
      await fetch('/api/user/balance', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId, amount })
      });
    } catch (error) {
      console.error('Error updating balance:', error);
    }
  };

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>
        Complete all missions first, get a bigger share of the hunt.
      </h1>
      <Tasks
        userId={userId}
        isWebApp={false}
        onBalanceUpdate={updateBalance}
      />
    </div>
  );
}
