'use client';

import { useState } from 'react';
import styles from '@/styles/Invite.module.css';

export default function Invite() {
  const [referralCode, setReferralCode] = useState('YOUR_REFERRAL_CODE');

  const handleCopyReferral = () => {
    navigator.clipboard.writeText(referralCode);
    // Add notification logic here
  };

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Invite Friends</h1>
      <div className={styles.referralBox}>
        <p className={styles.referralCode}>{referralCode}</p>
        <button 
          className={styles.copyButton}
          onClick={handleCopyReferral}
        >
          Copy Code
        </button>
      </div>
      <div className={styles.referralsList}>
        <h2>Your Referrals</h2>
        {/* Add referral list here */}
        <p className={styles.noReferrals}>No referrals yet</p>
      </div>
    </div>
  );
}
