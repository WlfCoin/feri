'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import styles from '@/styles/Miner.module.css';


const MINING_DURATION = 14400; // 4 hours in seconds

export default function Miner() {
  const { user } = useAuth();
  const [miningData, setMiningData] = useState(null);

  const fetchMiningData = async () => {
    if (!user?.id) return;

    const response = await fetch(`/api/mining/status?userId=${user.id}`);
    const result = await response.json();

    if (result.success) {
      setMiningData(result.data);
    }
  };

  useEffect(() => {
    fetchMiningData();
  }, [user]);

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours}:${minutes}:${secs}`;
  };

  if (!miningData) return <div>Loading...</div>;

  return (
    <div className="relative min-h-screen flex flex-col items-center px-4 py-8">
      <div className="w-full flex justify-between mb-12">
        <div className="w-[120px] h-[60px] bg-black/80 rounded-lg flex flex-col items-center justify-center">
          <div className="text-sm bg-gradient-to-r from-[#ff0000] to-[#ff4e00] bg-clip-text text-transparent">Hunt rate</div>
          <div className="font-bold bg-gradient-to-r from-[#ff0000] to-[#ff4e00] bg-clip-text text-transparent">{user?.miningRate.toFixed(2)}x</div>
        </div>
        <div className="w-[120px] h-[60px] bg-black/80 rounded-lg flex flex-col items-center justify-center">
          <div className="text-sm bg-gradient-to-r from-[#ff0000] to-[#ff4e00] bg-clip-text text-transparent">Total hunt</div>
          <div className="font-bold bg-gradient-to-r from-[#ff0000] to-[#ff4e00] bg-clip-text text-transparent">{miningData?.points_earned || 0}</div>
        </div>
      </div>

      <button
        onClick={() => {}} // Add mining logic here
        className="w-[200px] h-[200px] rounded-full bg-[url('/images/button.jpg')] bg-cover bg-center hover:opacity-90 transition-opacity flex items-center justify-center text-2xl font-bold mb-8 text-white"
      >
        {miningData?.status === 'active' ? formatTime(miningData.timeLeft) : 'GO HUNT'}
      </button>

      <div className="w-[150px] h-[50px] bg-black/80 rounded-lg flex items-center justify-center mb-12">
        <div className="text-sm bg-gradient-to-r from-[#ff0000] to-[#ff4e00] bg-clip-text text-transparent">
          {user?.username || 'Guest'}
        </div>
      </div>
    </div>
  );
}
