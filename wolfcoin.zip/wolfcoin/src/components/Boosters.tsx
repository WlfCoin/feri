'use client';

import React, { useState, useEffect } from 'react';
import { useTonConnect } from './TonConnectProvider';
import styles from '@/styles/Boosters.module.css';

interface Booster {
  id: string;
  name: string;
  cost: number;
  rate: number;
  type: 'HUNTING_RATE' | 'OFFLINE_HUNT';
  requiredBoosterId?: string;
}

const WALLET_ADDRESS = 'UQDdllvTeXTYE_2mq9R9hsEn_M1W4gACpoaumZtbLoIyrrYh';

const HUNTING_RATE_PLANS: Booster[] = [
  { id: 'hr1', name: 'Basic Hunter', cost: 0.2, rate: 0.6, type: 'HUNTING_RATE' },
  { id: 'hr2', name: 'Advanced Hunter', cost: 0.4, rate: 0.7, type: 'HUNTING_RATE', requiredBoosterId: 'hr1' },
  { id: 'hr3', name: 'Expert Hunter', cost: 0.6, rate: 0.8, type: 'HUNTING_RATE', requiredBoosterId: 'hr2' },
  { id: 'hr4', name: 'Master Hunter', cost: 0.8, rate: 0.9, type: 'HUNTING_RATE', requiredBoosterId: 'hr3' },
  { id: 'hr5', name: 'Elite Hunter', cost: 1.0, rate: 1.0, type: 'HUNTING_RATE', requiredBoosterId: 'hr4' },
  { id: 'hr6', name: 'Legend Hunter', cost: 1.2, rate: 1.2, type: 'HUNTING_RATE', requiredBoosterId: 'hr5' },
  { id: 'hr7', name: 'Mythic Hunter', cost: 1.4, rate: 1.3, type: 'HUNTING_RATE', requiredBoosterId: 'hr6' },
  { id: 'hr8', name: 'Divine Hunter', cost: 1.6, rate: 1.5, type: 'HUNTING_RATE', requiredBoosterId: 'hr7' },
  { id: 'hr9', name: 'Celestial Hunter', cost: 1.8, rate: 1.7, type: 'HUNTING_RATE', requiredBoosterId: 'hr8' },
  { id: 'hr10', name: 'Supreme Hunter', cost: 2.0, rate: 2.0, type: 'HUNTING_RATE', requiredBoosterId: 'hr9' }
];

const OFFLINE_HUNT_PLANS: Booster[] = [
  { id: 'oh1', name: '6 Hours Offline', cost: 0.2, rate: 6, type: 'OFFLINE_HUNT' },
  { id: 'oh2', name: '8 Hours Offline', cost: 0.4, rate: 8, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh1' },
  { id: 'oh3', name: '10 Hours Offline', cost: 0.6, rate: 10, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh2' },
  { id: 'oh4', name: '12 Hours Offline', cost: 0.8, rate: 12, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh3' },
  { id: 'oh5', name: '14 Hours Offline', cost: 1.0, rate: 14, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh4' },
  { id: 'oh6', name: '16 Hours Offline', cost: 1.2, rate: 16, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh5' },
  { id: 'oh7', name: '18 Hours Offline', cost: 1.4, rate: 18, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh6' },
  { id: 'oh8', name: '20 Hours Offline', cost: 1.6, rate: 20, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh7' },
  { id: 'oh9', name: '22 Hours Offline', cost: 1.8, rate: 22, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh8' },
  { id: 'oh10', name: '24 Hours Offline', cost: 2.0, rate: 24, type: 'OFFLINE_HUNT', requiredBoosterId: 'oh9' }
];

interface ActiveBooster {
  id: string;
  name: string;
  rate: number;
  type: string;
  expiryDate: string | null;
}

export default function Boosters() {
  const { tonConnectUI, connected } = useTonConnect();
  const [expandedSection, setExpandedSection] = useState<'HUNTING_RATE' | 'OFFLINE_HUNT' | null>(null);
  const [activeBoosters, setActiveBoosters] = useState<ActiveBooster[]>([]);

  useEffect(() => {
    // Load active boosters from backend
    // TODO: Implement this
  }, []);

  const handlePurchase = async (booster: Booster) => {
    if (!connected || !tonConnectUI) {
      alert('Please connect your wallet first');
      return;
    }

    try {
      const transaction = {
        validUntil: Math.floor(Date.now() / 1000) + 60,
        messages: [
          {
            address: WALLET_ADDRESS,
            amount: (booster.cost * 1000000000).toString(),
          },
        ],
      };

      const result = await tonConnectUI.sendTransaction(transaction);
      
      if (result) {
        // Update active boosters
        setActiveBoosters(prev => [...prev, {
          id: booster.id,
          name: booster.name,
          rate: booster.rate,
          type: booster.type,
          expiryDate: null
        }]);

        // TODO: Send transaction result to backend
      }
    } catch (error) {
      console.error('Transaction failed:', error);
      alert('Transaction failed. Please try again.');
    }
  };

  return (
    <div className="space-y-8">
      {/* Hunting Rate Boosters Section */}
      <div className="rounded-lg overflow-hidden">
        <button
          onClick={() => setExpandedSection(expandedSection === 'HUNTING_RATE' ? null : 'HUNTING_RATE')}
          className="w-full bg-black/80 p-4 flex justify-between items-center text-[#ff4e00] hover:bg-black/90 transition-colors"
        >
          <span className="text-xl font-bold">Hunting Rate Boosters</span>
          <span>{expandedSection === 'HUNTING_RATE' ? '▼' : '▶'}</span>
        </button>
        
        {expandedSection === 'HUNTING_RATE' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 bg-black/60">
            {HUNTING_RATE_PLANS.map((booster) => {
              const isActive = activeBoosters.some(ab => ab.id === booster.id);
              const hasPrerequisite = !booster.requiredBoosterId || 
                activeBoosters.some(ab => ab.id === booster.requiredBoosterId);

              return (
                <div 
                  key={booster.id} 
                  className={`bg-black/80 rounded-lg p-6 ${!hasPrerequisite ? 'opacity-50' : ''}`}
                >
                  <h3 className="text-xl font-bold mb-2 bg-gradient-to-r from-[#ff0000] to-[#ff4e00] bg-clip-text text-transparent">
                    {booster.name}
                  </h3>
                  <div className="text-[#ff4e00] mb-4">
                    <p>Rate: {booster.rate} points/hour</p>
                    {booster.requiredBoosterId && (
                      <p className="text-sm opacity-80">
                        Requires: {HUNTING_RATE_PLANS.find(b => b.id === booster.requiredBoosterId)?.name}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold text-[#ff4e00]">{booster.cost} TON</span>
                    <button
                      onClick={() => handlePurchase(booster)}
                      disabled={isActive || !hasPrerequisite}
                      className={`px-4 py-2 rounded font-semibold ${
                        isActive
                          ? 'bg-[#ff4e00]/50 text-white cursor-not-allowed'
                          : !hasPrerequisite
                          ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                          : 'bg-gradient-to-r from-[#ff0000] to-[#ff4e00] hover:opacity-90 text-white'
                      }`}
                    >
                      {isActive ? 'Active' : 'Purchase'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Offline Hunt Boosters Section */}
      <div className="rounded-lg overflow-hidden">
        <button
          onClick={() => setExpandedSection(expandedSection === 'OFFLINE_HUNT' ? null : 'OFFLINE_HUNT')}
          className="w-full bg-black/80 p-4 flex justify-between items-center text-[#ff4e00] hover:bg-black/90 transition-colors"
        >
          <span className="text-xl font-bold">Offline Hunt Boosters</span>
          <span>{expandedSection === 'OFFLINE_HUNT' ? '▼' : '▶'}</span>
        </button>
        
        {expandedSection === 'OFFLINE_HUNT' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 bg-black/60">
            {OFFLINE_HUNT_PLANS.map((booster) => {
              const isActive = activeBoosters.some(ab => ab.id === booster.id);
              const hasPrerequisite = !booster.requiredBoosterId || 
                activeBoosters.some(ab => ab.id === booster.requiredBoosterId);

              return (
                <div 
                  key={booster.id} 
                  className={`bg-black/80 rounded-lg p-6 ${!hasPrerequisite ? 'opacity-50' : ''}`}
                >
                  <h3 className="text-xl font-bold mb-2 bg-gradient-to-r from-[#ff0000] to-[#ff4e00] bg-clip-text text-transparent">
                    {booster.name}
                  </h3>
                  <div className="text-[#ff4e00] mb-4">
                    <p>Duration: {booster.rate} hours</p>
                    {booster.requiredBoosterId && (
                      <p className="text-sm opacity-80">
                        Requires: {OFFLINE_HUNT_PLANS.find(b => b.id === booster.requiredBoosterId)?.name}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold text-[#ff4e00]">{booster.cost} TON</span>
                    <button
                      onClick={() => handlePurchase(booster)}
                      disabled={isActive || !hasPrerequisite}
                      className={`px-4 py-2 rounded font-semibold ${
                        isActive
                          ? 'bg-[#ff4e00]/50 text-white cursor-not-allowed'
                          : !hasPrerequisite
                          ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                          : 'bg-gradient-to-r from-[#ff0000] to-[#ff4e00] hover:opacity-90 text-white'
                      }`}
                    >
                      {isActive ? 'Active' : 'Purchase'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
