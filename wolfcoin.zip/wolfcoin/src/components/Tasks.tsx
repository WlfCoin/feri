'use client';

import React, { useState, useEffect } from 'react';
import styles from '@/styles/Tasks.module.css';


interface Task {
  id: string;
  title: string;
  description: string;
  reward: number;
  platform: 'telegram' | 'twitter' | 'youtube' | 'instagram';
  link: string;
  status: 'pending' | 'waiting' | 'completed' | 'failed';
  verificationMethod: 'bot' | 'api' | 'admin';
}

interface TasksProps {
  userId: number;
  isWebApp: boolean;
  onBalanceUpdate?: (amount: number) => void;
}

const REWARD_POINTS = 2;
const MEMBERSHIP_CHECK_INTERVAL = 12 * 60 * 60 * 1000; // 12 hours in milliseconds
const PENALTY_PERCENTAGE = 5;
const BOT_USERNAME = process.env.NEXT_PUBLIC_BOT_USERNAME || 'WolfCoinrobot';

const defaultTasks: { [key: string]: Task[] } = {
  community: [
    {
      id: 'telegram_news',
      title: 'Join News Channel',
      description: 'Join our Telegram news channel to stay updated',
      reward: REWARD_POINTS,
      platform: 'telegram',
      link: process.env.NEXT_PUBLIC_CHANNEL_ID || 'https://t.me/WolfCoin_news',
      status: 'pending',
      verificationMethod: 'bot'
    },
    {
      id: 'telegram_activity',
      title: 'Join Activity Channel',
      description: 'Join our Telegram activity channel',
      reward: REWARD_POINTS,
      platform: 'telegram',
      link: process.env.NEXT_PUBLIC_ACTIVITY_CHANNEL || 'https://t.me/Activityofprojectusers',
      status: 'pending',
      verificationMethod: 'bot'
    },
    {
      id: 'twitter_follow',
      title: 'Join X (Twitter)',
      description: 'Follow our official Twitter account',
      reward: REWARD_POINTS,
      platform: 'twitter',
      link: 'https://x.com/wlfcoinofficial?t=x6TDbhipSMYkU4bWw_dI_g&s=09',
      status: 'pending',
      verificationMethod: 'api'
    },
    {
      id: 'youtube_subscribe',
      title: 'Join YouTube',
      description: 'Subscribe to our YouTube channel',
      reward: REWARD_POINTS,
      platform: 'youtube',
      link: 'https://youtube.com/@wolfcoinofficial?si=XnwRU0MH_DY9hFFc',
      status: 'pending',
      verificationMethod: 'api'
    },
    {
      id: 'instagram_follow',
      title: 'Join Instagram',
      description: 'Follow our Instagram account',
      reward: REWARD_POINTS,
      platform: 'instagram',
      link: 'https://www.instagram.com/wolfcoin.official/profilecard/?igsh=MWRpa2p1ZmU4OGVzMg==7',
      status: 'pending',
      verificationMethod: 'admin'
    }
  ],
  partner: [],
  academy: []
};

const Tasks = ({ userId, isWebApp, onBalanceUpdate }: TasksProps) => {
  const [tasks, setTasks] = useState<{ [key: string]: Task[] }>(defaultTasks);
  const [activeTab, setActiveTab] = useState<'community' | 'partner' | 'academy'>('community');
  const [showInstagramModal, setShowInstagramModal] = useState(false);
  const [instagramUsername, setInstagramUsername] = useState('');
  const [currentTask, setCurrentTask] = useState<Task | null>(null);

  useEffect(() => {
    // لود کردن وضعیت تسک‌ها از localStorage
    const savedTasks = localStorage.getItem(`tasks_${userId}`);
    if (savedTasks) {
      setTasks(JSON.parse(savedTasks));
    }

    // چک کردن عضویت در کانال‌های تلگرام هر 12 ساعت
    const checkMembership = async () => {
      try {
        const telegramTasks = tasks.community.filter(t => t.platform === 'telegram' && t.status === 'completed');
        
        for (const task of telegramTasks) {
          const response = await fetch(`/api/telegram/check-membership`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              userId,
              channelId: task.id === 'telegram_news' ? 
                process.env.NEXT_PUBLIC_CHANNEL_ID : 
                process.env.NEXT_PUBLIC_ACTIVITY_CHANNEL
            })
          });

          const data = await response.json();
          if (!data.isMember) {
            applyPenalty();
            stopMining();
            updateTaskStatus(task.id, 'failed');
          }
        }
      } catch (error) {
        console.error('Error checking membership:', error);
      }
    };

    const interval = setInterval(checkMembership, MEMBERSHIP_CHECK_INTERVAL);
    return () => clearInterval(interval);
  }, [userId, tasks]);

  // ذخیره وضعیت تسک‌ها در localStorage
  useEffect(() => {
    localStorage.setItem(`tasks_${userId}`, JSON.stringify(tasks));
  }, [tasks, userId]);

  const applyPenalty = () => {
    const currentBalance = parseFloat(localStorage.getItem('taskBalance') || '0');
    const penalty = currentBalance * (PENALTY_PERCENTAGE / 100);
    const newBalance = currentBalance - penalty;
    localStorage.setItem('taskBalance', newBalance.toString());
    
    if (onBalanceUpdate) {
      onBalanceUpdate(-penalty);
    }
  };

  const stopMining = () => {
    localStorage.removeItem('miningState');
    window.location.reload(); // ریلود صفحه برای توقف ماینینگ
  };

  const updateTaskStatus = (taskId: string, status: Task['status']) => {
    const updatedTasks = { ...tasks };
    updatedTasks[activeTab] = updatedTasks[activeTab].map(t => 
      t.id === taskId ? { ...t, status } : t
    );
    setTasks(updatedTasks);
  };

  const handleTaskClick = async (task: Task) => {
    if (task.status !== 'pending' && task.status !== 'failed') return;

    if (task.platform === 'instagram') {
      setCurrentTask(task);
      setShowInstagramModal(true);
      return;
    }

    // باز کردن لینک در تب جدید
    if (task.platform === 'telegram') {
      // برای تلگرام، باز کردن بات برای تأیید
      window.open(`https://t.me/${BOT_USERNAME}?start=verify_${task.id}_${userId}`, '_blank');
    } else {
      window.open(task.link, '_blank');
    }
    
    updateTaskStatus(task.id, 'waiting');
    
    try {
      let verified = false;

      switch (task.verificationMethod) {
        case 'bot':
          // شروع پولینگ برای چک کردن وضعیت تأیید
          verified = await pollVerificationStatus(task.id);
          break;
        case 'api':
          verified = await verifyWithAPI(task.platform, task.id);
          break;
        case 'admin':
          return; // برای اینستاگرام در handleInstagramSubmit انجام میشه
      }

      if (verified) {
        updateTaskStatus(task.id, 'completed');
        if (onBalanceUpdate) {
          onBalanceUpdate(task.reward);
        }
      }
    } catch (error) {
      console.error('Verification failed:', error);
      updateTaskStatus(task.id, 'failed');
    }
  };

  const pollVerificationStatus = async (taskId: string): Promise<boolean> => {
    let attempts = 0;
    const maxAttempts = 30; // 5 دقیقه (10 ثانیه * 30)

    while (attempts < maxAttempts) {
      try {
        const response = await fetch(`/api/telegram/verify-task`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            userId,
            taskId
          })
        });

        const data = await response.json();
        if (data.verified) {
          return true;
        }

        attempts++;
        await new Promise(resolve => setTimeout(resolve, 10000)); // 10 ثانیه صبر
      } catch (error) {
        console.error('Error polling verification status:', error);
        return false;
      }
    }

    return false;
  };

  const verifyWithAPI = async (platform: 'telegram' | 'twitter' | 'youtube', taskId: string) => {
    try {
      const response = await fetch(`/api/${platform}/verify-task`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          taskId,
        }),
      });

      const data = await response.json();
      return data.verified;
    } catch (error) {
      console.error(`Error verifying ${platform} task:`, error);
      return false;
    }
  };

  const handleInstagramSubmit = async () => {
    if (!currentTask || !instagramUsername) return;

    try {
      const response = await fetch('/api/instagram/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          username: instagramUsername
        })
      });

      const data = await response.json();
      
      if (data.success) {
        updateTaskStatus(currentTask.id, 'waiting');
        setShowInstagramModal(false);
        setInstagramUsername('');
      } else {
        alert(data.message || 'Error submitting Instagram username');
      }
    } catch (error) {
      console.error('Error submitting Instagram username:', error);
      alert('Error submitting Instagram username');
    }
  };

  return (
    <div className={styles.tasksContainer}>
      <div className={styles.tabsContainer}>
        <button 
          className={`${styles.tabButton} ${activeTab === 'community' ? styles.active : ''}`}
          onClick={() => setActiveTab('community')}
        >
          Community Tasks
        </button>
        <button 
          className={`${styles.tabButton} ${activeTab === 'partner' ? styles.active : ''}`}
          onClick={() => setActiveTab('partner')}
        >
          Partner Tasks
        </button>
        <button 
          className={`${styles.tabButton} ${activeTab === 'academy' ? styles.active : ''}`}
          onClick={() => setActiveTab('academy')}
        >
          Academy Tasks
        </button>
      </div>

      <div className={styles.tabContent}>
        <div className={styles.taskList}>
          {tasks[activeTab].map((task) => (
            <div 
              key={task.id} 
              className={`${styles.task} ${task.status === 'waiting' ? styles.waiting : ''} ${
                task.status === 'completed' ? styles.completed : ''
              } ${task.status === 'failed' ? styles.failed : ''}`}
              onClick={() => handleTaskClick(task)}
            >
              <div className={styles.taskInfo}>
                <h3>{task.title}</h3>
                <p>{task.description}</p>
                <span className={styles.reward}>+{task.reward} Points</span>
              </div>
              <div className={styles.taskStatus}>
                {task.status === 'completed' && 'Completed'}
                {task.status === 'waiting' && 'Verifying...'}
                {task.status === 'failed' && 'Failed - Retry'}
                {task.status === 'pending' && 'Join'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {showInstagramModal && (
        <div className={styles.modal}>
          <div className={styles.modalContent}>
            <h3>Enter Instagram Username</h3>
            <p>Please enter your Instagram username for verification:</p>
            <input
              type="text"
              className={styles.input}
              value={instagramUsername}
              onChange={(e) => setInstagramUsername(e.target.value)}
              placeholder="@username"
            />
            <div className={styles.modalButtons}>
              <button 
                className={styles.cancelButton}
                onClick={() => {
                  setShowInstagramModal(false);
                  setInstagramUsername('');
                  setCurrentTask(null);
                }}
              >
                Cancel
              </button>
              <button 
                className={styles.submitButton}
                onClick={handleInstagramSubmit}
                disabled={!instagramUsername}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Tasks;
