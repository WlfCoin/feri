'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { useTonConnect } from '@/components/TonConnectProvider';

interface User {
  id: number;
  address: string;
  username: string;
  balance: number;
  miningRate: number;
  lastMined: Date;
}

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  loading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  updateUserBalance: (amount: number) => Promise<void>;
  updateMiningRate: (rate: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoggedIn: false,
  loading: true,
  login: async () => {},
  logout: async () => {},
  updateUserBalance: async () => {},
  updateMiningRate: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const { wallet, connected } = useTonConnect();

  const isLoggedIn = !!user;

  useEffect(() => {
    if (connected && wallet?.account?.address) {
      login();
    } else {
      setUser(null);
    }
  }, [connected, wallet?.account?.address]);

  const login = async () => {
    try {
      if (!wallet?.account?.address) return;

      setLoading(true);
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          address: wallet.account.address,
        }),
      });

      if (!response.ok) throw new Error('Login failed');

      const userData = await response.json();
      setUser(userData);
    } catch (error) {
      alert('Login failed. Please try again.');
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
      });
      setUser(null);
    } catch (error) {
      alert('Logout failed. Please try again.');
      console.error('Logout error:', error);
    }
  };

  const updateUserBalance = async (amount: number) => {
    if (!user) return;
    try {
      setLoading(true);
      const response = await fetch('/api/user/balance', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.id,
          amount,
          updatedAt: new Date().toISOString(),
        }),
      });

      if (!response.ok) throw new Error('Failed to update balance');

      const updatedUser = await response.json();
      setUser(updatedUser);
    } catch (error) {
      alert('Failed to update balance.');
      console.error('Update balance error:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateMiningRate = async (rate: number) => {
    if (!user) return;
    try {
      setLoading(true);
      const response = await fetch('/api/user/mining-rate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.id,
          rate,
          updatedAt: new Date().toISOString(),
        }),
      });

      if (!response.ok) throw new Error('Failed to update mining rate');

      const updatedUser = await response.json();
      setUser(updatedUser);
    } catch (error) {
      alert('Failed to update mining rate.');
      console.error('Update mining rate error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoggedIn,
        loading,
        login,
        logout,
        updateUserBalance,
        updateMiningRate,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
