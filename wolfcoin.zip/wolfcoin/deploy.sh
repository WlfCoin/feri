#!/bin/bash

# Exit on error
set -e

echo "Starting WolfCoin deployment..."

# Variables
DEPLOY_PATH="/var/www/wolfcoin"
FRONTEND_PATH="$DEPLOY_PATH"
BOT_PATH="$DEPLOY_PATH/bot"
LOG_PATH="/var/log/wolfcoin"
DB_PASSWORD="WolfCoin2025Secure"

# Security: Set strict permissions
umask 027

# Create necessary directories with secure permissions
echo "Creating directories..."
sudo install -d -m 750 -o www-data -g www-data $DEPLOY_PATH $BOT_PATH $LOG_PATH

# Install security packages
echo "Installing security packages..."
sudo apt-get update
sudo apt-get install -y \
  fail2ban \
  ufw \
  unattended-upgrades \
  apt-listchanges

# Configure firewall
echo "Configuring firewall..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable

# Configure fail2ban
echo "Configuring fail2ban..."
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# Configure PostgreSQL user and permissions
echo "Configuring PostgreSQL user and permissions..."
sudo -u postgres psql << EOF
ALTER USER farhad WITH PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE wolfcoin TO farhad;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO farhad;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO farhad;
EOF

# Install Node.js dependencies and build frontend
echo "Setting up frontend..."
cd $FRONTEND_PATH
rm -rf node_modules package-lock.json
npm install
npx tailwindcss init -p
npm run build

# Setup Python virtual environment for bot with secure permissions
echo "Setting up bot..."
cd $BOT_PATH
python3 -m venv venv
source venv/bin/activate
pip install --no-cache-dir -r requirements.txt

# Create environment files with secure permissions
echo "Creating environment files..."

# Frontend .env
cat > $FRONTEND_PATH/.env <<EOF
NEXT_PUBLIC_API_URL=https://wolfcoin.net/api
NEXT_PUBLIC_BOT_URL=https://wolfcoin.net/bot
NEXT_PUBLIC_WEBAPP_URL=https://wolfcoin.net
NEXT_PUBLIC_BOT_USERNAME=WolfCoinrobot
NEXT_PUBLIC_ADMIN_ID=5375624171
NEXT_PUBLIC_CHANNEL_ID=@WolfCoin_news
NEXT_PUBLIC_ACTIVITY_CHANNEL=@Activityofprojectusers
NEXT_PUBLIC_TON_WALLET_ADDRESS=UQDdllvTeXTYE_2mq9R9hsEn_M1W4gACpoaumZtbLoIyrrYh
NEXT_PUBLIC_TON_NETWORK=mainnet
NEXT_PUBLIC_TON_ENDPOINTS=["https://toncenter.com/api/v2/jsonRPC"]
NEXT_PUBLIC_TON_API_KEY=32c6d3cb3a6a5e4e1e6c4a6e8a9c2f5b
DATABASE_URL=postgresql://farhad:$DB_PASSWORD@localhost:5432/wolfcoin
NODE_ENV=production
EOF

# Bot .env
cat > $BOT_PATH/.env <<EOF
TELEGRAM_BOT_TOKEN=7680841779:AAEtnUxqSxhmL3X3c_d2OiRL0lOBnOFZrE0
ADMIN_ID=5375624171
API_URL=http://localhost:3000
DATABASE_URL=postgresql://farhad:$DB_PASSWORD@localhost:5432/wolfcoin
TON_WALLET_ADDRESS=UQDdllvTeXTYE_2mq9R9hsEn_M1W4gACpoaumZtbLoIyrrYh
CHANNEL_ID=@WolfCoin_news
ACTIVITY_CHANNEL=@Activityofprojectusers
EOF

# Set secure permissions for environment files
sudo chown www-data:www-data $FRONTEND_PATH/.env $BOT_PATH/.env
sudo chmod 640 $FRONTEND_PATH/.env $BOT_PATH/.env

# Setup Supervisor with secure config
echo "Setting up Supervisor..."
sudo cp supervisor/*.conf /etc/supervisor/conf.d/
sudo chown root:root /etc/supervisor/conf.d/*.conf
sudo chmod 644 /etc/supervisor/conf.d/*.conf

# Reload Supervisor
sudo supervisorctl reread
sudo supervisorctl update

# Setup Nginx with secure config
echo "Setting up Nginx..."
sudo cp nginx/wolfcoin.conf /etc/nginx/sites-available/
sudo chown root:root /etc/nginx/sites-available/wolfcoin.conf
sudo chmod 644 /etc/nginx/sites-available/wolfcoin.conf
sudo ln -sf /etc/nginx/sites-available/wolfcoin.conf /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Install Certbot and get SSL certificate
echo "Installing Certbot and obtaining SSL certificate..."
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d wolfcoin.net -d www.wolfcoin.net --non-interactive --agree-tos --email admin@wolfcoin.net --redirect

# Verify SSL renewal works
echo "Testing SSL auto-renewal..."
sudo certbot renew --dry-run

# Setup automatic security updates
echo "Configuring automatic security updates..."
sudo dpkg-reconfigure -plow unattended-upgrades

echo "Deployment completed successfully!"
echo "Security measures implemented:"
echo "1. Firewall (UFW) configured"
echo "2. Fail2ban installed and configured"
echo "3. Secure file permissions set"
echo "4. PostgreSQL security settings applied"
echo "5. Automatic security updates enabled"
echo "6. Environment files protected"
echo "7. SSL certificates installed and auto-renewal configured"
